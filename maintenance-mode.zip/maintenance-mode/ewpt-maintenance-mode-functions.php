<?php
// essential-wp-tools/modules/maintenance-mode/ewpt-maintenance-mode-functions.php

// Define namespace
namespace EWPT\Modules\EssentialTools;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
