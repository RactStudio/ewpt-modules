<?php
// essential-wp-tools/modules/maintenance-mode/lib/ewpt-maintenance-mode-activation.php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Execute once (first time) the main plugin (EWPT) activation (not this module activation)

