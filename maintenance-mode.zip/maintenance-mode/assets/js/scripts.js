/**
** EWPT
** Maintenance Mode JavaScripts
**/