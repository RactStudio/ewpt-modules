<?php
// essential-wp-tools/modules/sample-module/ewpt-sample-module-actions.php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
