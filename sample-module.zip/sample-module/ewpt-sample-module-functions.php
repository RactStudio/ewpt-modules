<?php
// essential-wp-tools/modules/sample-module/ewpt-sample-module-functions.php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
