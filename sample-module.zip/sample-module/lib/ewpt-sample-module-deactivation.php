<?php
// essential-wp-tools/modules/sample-module/lib/ewpt-sample-module-deactivation.php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Execute each time the main plugin (EWPT) deactivation (not this module deactivation)

