<?php
// essential-wp-tools/modules/sample-module/lib/ewpt-sample-module-activation.php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Execute once (first time) the main plugin (EWPT) activation (not this module activation)

