<?php
// essential-wp-tools/modules/social-share-hub/lib/ewpt-social-share-hub-deactivation.php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Execute each time the main plugin (EWPT) deactivation (not this module deactivation)

