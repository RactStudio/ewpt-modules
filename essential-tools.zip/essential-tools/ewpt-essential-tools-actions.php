<?php
// essential-wp-tools/modules/essential-tools/ewpt-essential-tools-actions.php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
