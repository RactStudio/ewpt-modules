<?php
// essential-wp-tools/modules/essential-tools/lib/ewpt-essential-tools-deactivation.php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Execute each time the main plugin (EWPT) deactivation (not this module deactivation)

