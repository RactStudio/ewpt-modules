<?php
// essential-wp-tools/modules/ad-insert-hub/lib/ewpt-ad-insert-hub-deactivation.php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Execute each time the main plugin (EWPT) deactivation (not this module deactivation)

