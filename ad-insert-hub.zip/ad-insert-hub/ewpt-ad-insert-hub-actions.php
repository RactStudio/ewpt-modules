<?php
// essential-wp-tools/modules/ad-insert-hub/ewpt-ad-insert-hub-actions.php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
