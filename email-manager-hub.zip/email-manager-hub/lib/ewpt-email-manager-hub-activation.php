<?php
// essential-wp-tools/modules/email-manager-hub/lib/ewpt-email-manager-hub-activation.php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Execute once (first time) the main plugin (EWPT) activation (not this module activation)

