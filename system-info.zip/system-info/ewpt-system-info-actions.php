<?php
// essential-wp-tools/modules/system-info/ewpt-system-info-actions.php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
